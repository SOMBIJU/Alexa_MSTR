// Initialize the viz variable 


window.onload= function() {
// When the webpage has loaded, load the viz
    
};

// Switch the viz to the sheet specified
function switchView(sheetName) {
	
}

// Filter the specified dimension to the specified value(s)
function show(filterName, values) {
    
}

// Select the marks that have the specified value(s) for the specified dimension
function selectMarks(filterName, values) {
    
}
