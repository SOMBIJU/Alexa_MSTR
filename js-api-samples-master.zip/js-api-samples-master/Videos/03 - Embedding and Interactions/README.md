# JSAPIVideos - 03 - Embedding and Interactions
Companion code to the Tableau JavaScript API Video on Embedding and Interactions

##This video teaches you how to (using the JSAPI):
- Embed Tableau workbooks into a webpage
- Switch tabs
- Filter
- Select Marks